let arr = [1, 2, 3];

arr.unshift(99);  // 把99 擺在陣列的第一個位置
arr.unshift(100);

console.log(arr);