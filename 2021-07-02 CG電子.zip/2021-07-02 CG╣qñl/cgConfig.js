
module.exports = {

    apiURL: 'http://testenv-dev.cg11systems.com/client/api/getGameRecord.php'
    , ChannelID: '77668'
    , Key: 'Pf9t8OaUDC4sjWxFZ3HKfnE3wSAIValVqtwOqLdtCw4='
    , IV: 'MJ2MTl6sSHYLLmdu4T5Hxg=='
}
